# The MIT License (MIT)
# Copyright (c) 2021 Microsoft Corporation

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Internal class for query execution context implementation in the Azure Cosmos
database service.
"""

from collections import deque
import copy
import logging

from ...aio import _retry_utility_async
from ... import http_constants, exceptions, _base

_LOGGER = logging.getLogger(__name__)

# pylint: disable=protected-access


class _QueryExecutionContextBase(object):
    """
    This is the abstract base execution context class.
    """

    def __init__(self, client, options):
        """
        :param CosmosClient client:
        :param dict options: The request options for the request.
        """
        self._client = client
        self._options = options
        self._continuation = self._get_initial_continuation()
        self._has_started = False
        self._has_finished = False
        self._buffer = deque()
        self._resource_link = None
        # Per-query mutable capture used by __QueryFeed to report response
        # headers (including failure checkpoints) without crossing requests.
        self._internal_response_headers_capture = {}

    def _get_initial_continuation(self):
        if "continuation" in self._options:
            return self._options["continuation"]
        return None

    def _has_more_pages(self):
        return not self._has_finished

    async def _ensure(self):
        if not self._has_more_pages():
            return

        if not self._buffer:
            results = await self._fetch_next_block()
            self._buffer.extend(results)

        if not self._buffer:
            self._has_finished = True

    async def fetch_next_block(self):
        """Returns a block of results with respecting retry policy.

        This method only exists for backward compatibility reasons. (Because
        QueryIterable has exposed fetch_next_block api).

        :return: List of results.
        :rtype: list
        """
        await self._ensure()
        res = list(self._buffer)
        self._buffer.clear()
        return res

    async def _fetch_next_block(self):
        raise NotImplementedError

    def __aiter__(self):
        """Returns itself as an iterator
        :returns: Query as an iterator.
        :rtype: Iterator
        """
        return self

    async def __anext__(self):
        """Return the next query result.

        :return: The next query result.
        :rtype: dict
        :raises StopAsyncIteration: If no more result is left.
        """
        await self._ensure()

        if not self._buffer:
            raise StopAsyncIteration

        return self._buffer.popleft()

    async def _fetch_items_helper_no_retries(self, fetch_function):
        """Fetches more items and doesn't retry on failure

        :param Callable fetch_function: The function that fetches the items.
        :return: List of fetched items.
        :rtype: list
        """
        fetched_items = []
        new_options = copy.deepcopy(self._options)
        # Clear stale values from prior pages before issuing a new fetch.
        self._internal_response_headers_capture.clear()
        while self._continuation or not self._has_started:
            new_options["continuation"] = self._continuation
            # Reattach on every iteration: __QueryFeed pops this key off
            # `options`, so without re-setting it here later loop iterations
            # (empty-page-with-continuation case) would lose the capture and
            # the 410 retry layer would resume from stale headers.
            new_options["_internal_response_headers_capture"] = self._internal_response_headers_capture

            response_headers = {}
            (fetched_items, response_headers) = await fetch_function(new_options)
            if not self._has_started:
                self._has_started = True

            continuation_key = http_constants.HttpHeaders.Continuation
            self._continuation = response_headers.get(continuation_key)

            if fetched_items:
                break
        return fetched_items

    async def _fetch_items_helper_with_retries(self, fetch_function):
        # TODO: Properly propagate kwargs from retry utility to fetch function
        # the callback keep the **kwargs parameter to maintain compatibility with the retry utility's execution pattern.
        # ExecuteAsync passes retry context parameters (timeout, operation start time, logger, etc.)
        # The callback need to accept these parameters even if unused
        # Removing **kwargs results in a TypeError when ExecuteAsync tries to pass these parameters
        async def execute_fetch():
            async def callback(**kwargs):  # pylint: disable=unused-argument
                return await self._fetch_items_helper_no_retries(fetch_function)

            return await _retry_utility_async.ExecuteAsync(
                self._client, self._client._global_endpoint_manager, callback, **self._options
            )

        # Check if this is an internal partition key range fetch - skip 410 retry logic to avoid recursion
        # When we call refresh_routing_map_provider(), it triggers _ReadPartitionKeyRanges which would
        # come through this same code path. If that also gets a 410 and tries to refresh, we get infinite recursion.
        is_pk_range_fetch = self._options.get("_internal_pk_range_fetch", False)
        if is_pk_range_fetch:
            # For partition key range queries, just execute without 410 partition split retry
            # The underlying retry utility will still handle other transient errors
            _LOGGER.debug("Partition split retry (async): Skipping 410 retry for internal PK range fetch")
            return await execute_fetch()

        max_retries = 3
        attempt = 0

        while attempt <= max_retries:
            try:
                return await execute_fetch()
            except exceptions.CosmosHttpResponseError as e:
                if exceptions._partition_range_is_gone(e):
                    attempt += 1
                    if attempt > max_retries:
                        _LOGGER.error(
                            "Partition split retry (async): Exhausted all %d retries. "
                            "state: _has_started=%s, _continuation=%s",
                            max_retries, self._has_started, self._continuation
                        )
                        raise  # Exhausted retries, propagate error

                    _LOGGER.warning(
                        "Partition split retry (async): 410 error (sub_status=%s). Attempt %d of %d. "
                        "Refreshing routing map and resetting state.",
                        getattr(e, 'sub_status', 'N/A'),
                        attempt,
                        max_retries
                    )

                    # Refresh routing map to get new partition key ranges.
                    collection_link = self._resource_link
                    if collection_link:
                        previous_routing_map = None
                        routing_map_provider = getattr(self._client, "_routing_map_provider", None)
                        if routing_map_provider is not None:
                            routing_map_cache = getattr(routing_map_provider, "_collection_routing_map_by_item", {})
                            if isinstance(routing_map_cache, dict):
                                # The cache is keyed by the normalized resource id,
                                # not the raw collection_link. Normalize via
                                # _base.GetResourceIdOrFullNameFromLink and fall back
                                # to the raw link only if normalization throws.
                                # Without this the .get() almost always returns None
                                # and the refresh below silently degrades to a full
                                # repopulation on every 410.
                                lookup_key = collection_link
                                try:
                                    lookup_key = _base.GetResourceIdOrFullNameFromLink(collection_link)
                                except (AttributeError, IndexError, TypeError, ValueError):
                                    _LOGGER.debug(
                                        "Partition split retry (async): could not normalize "
                                        "collection_link '%s'; using raw value for "
                                        "previous-routing-map lookup.",
                                        collection_link,
                                    )
                                previous_routing_map = routing_map_cache.get(lookup_key)
                        await self._client.refresh_routing_map_provider(
                            collection_link,
                            previous_routing_map,
                            self._options,
                        )
                    else:
                        await self._client.refresh_routing_map_provider()

                    # Reset execution context state for retry. If __QueryFeed already
                    # stamped a checkpoint continuation on failure, resume from it.
                    continuation_key = http_constants.HttpHeaders.Continuation
                    checkpoint_continuation = self._internal_response_headers_capture.get(continuation_key)
                    self._has_started = False
                    self._continuation = checkpoint_continuation
                    # Retry immediately (no backoff needed for partition splits)
                    continue
                raise  # Not a partition split error, propagate immediately

        # This should never be reached, but added for safety
        return []


class _DefaultQueryExecutionContext(_QueryExecutionContextBase):
    """
    This is the default execution context.
    """

    def __init__(self, client, options, fetch_function, resource_link=None):
        """
        :param CosmosClient client:
        :param dict options: The request options for the request.
        :param method fetch_function:
            Will be invoked for retrieving each page
        :param str resource_link:
            Optional collection link associated with this execution context.

            Example of `fetch_function`:

            >>> def result_fn(result):
            >>>     return result['Databases']

        """
        super(_DefaultQueryExecutionContext, self).__init__(client, options)
        self._fetch_function = fetch_function
        self._resource_link = resource_link

    async def _fetch_next_block(self):
        while super(_DefaultQueryExecutionContext, self)._has_more_pages() and not self._buffer:
            return await self._fetch_items_helper_with_retries(self._fetch_function)
